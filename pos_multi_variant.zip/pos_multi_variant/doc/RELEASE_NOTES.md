## Module <pos_multi_variant>

#### 19.06.2021
#### Version 13.0.1.0.0
##### ADD
- Initial commit for pos_multi_variant

#### 19.6.2021
#### Version 13.0.1.0.1
##### FIX
- Bug Fixed.
