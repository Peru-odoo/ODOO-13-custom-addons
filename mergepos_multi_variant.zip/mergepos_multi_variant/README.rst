POS Product Multi variant
=========================
* Configure products having variants

Installation
============
- www.odoo.com/documentation/13.0/setup/install.html
- Install our custom addon

License
-------
GNU AFFERO GENERAL PUBLIC LICENSE, Version 3 (AGPLv3)
(http://www.gnu.org/licenses/agpl.html)

Company
-------
* 'Aadplus IT <https://aadplusgroup.com/>`__

Credits
-------
* Developer:
   Sreejith sasidharan

Contacts
--------
* Mail Contact : info@aadplusgroup.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
This module is maintained by Aadplus IT Solutions.

For support and more information, please visit https://aadplusgroup.com

Further information
===================
HTML Description: `<static/description/index.html>`
