# See LICENSE file for full copyright and licensing details.

from . import test_sales_report_product_image
